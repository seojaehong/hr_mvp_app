# /home/ubuntu/upload/payslip/attendance_calculator.py
"""
Plan 020: 듀얼 모드 근로시간 계산기 - 모드 A: 출근 상태 기반 계산기

AttendanceBasedCalculator는 출근/결근/지각 등 일별 상태가 표기된 데이터를 기반으로
출근율, 근무일수, 공제일수, 실급여일수 등을 계산합니다.
"""

import logging
import datetime
from decimal import Decimal
from typing import List, Dict, Optional, Union, Any

# 현재 프로젝트의 스키마를 import 합니다.
from .work_time_schema import (
    AttendanceInputRecord, CompanySettings, GlobalWorkSettings, AttendanceSummary, SalaryBasis, ErrorDetails, 
    WorkTimeCalculationResult # WorkTimeProcessor가 반환하는 전체 결과 타입이지만, 여기서는 부분 결과를 만듦
)

# 로거 설정
logger = logging.getLogger(__name__)

class AttendanceBasedCalculator:
    def __init__(self, settings: Union[GlobalWorkSettings, Dict[str, Any]]):
        """
        AttendanceBasedCalculator 초기화.

        Args:
            settings: 회사별 및 모듈 운영 설정을 담은 GlobalWorkSettings 객체 또는 설정 딕셔너리.
                      특히 `attendance_status_codes` 정의가 중요합니다.
        """
        self.settings = settings
        if isinstance(settings, dict):
            company_settings = settings.get("company_settings", {})
            self.status_codes_map = company_settings.get("attendance_status_codes", {})
        else:
            self.status_codes_map = settings.company_settings.attendance_status_codes
        logger.info("AttendanceBasedCalculator initialized.")

    def _get_days_in_month(self, period: str) -> int:
        """YYYY-MM 형식의 기간 문자열로부터 해당 월의 총 일수를 반환합니다."""
        try:
            year, month = map(int, period.split("-"))
            if month == 12:
                return (datetime.date(year + 1, 1, 1) - datetime.date(year, month, 1)).days
            return (datetime.date(year, month + 1, 1) - datetime.date(year, month, 1)).days
        except ValueError:
            logger.error(f"Invalid period format: {period}. Expected YYYY-MM.")
            # 기본값 또는 예외 발생 처리
            return 30 # 단순 기본값, 실제로는 오류 처리 필요

    def _get_scheduled_work_days(self, period: str, total_days_in_month: int) -> int:
        """
        해당 월의 소정근로일수를 계산합니다. (주말, 공휴일 제외)
        이 예시에서는 간단히 주말만 제외하며, 공휴일은 settings에서 가져와야 합니다.
        """
        year, month = map(int, period.split("-"))
        scheduled_days = 0
        # 공휴일 목록 (settings에서 가져와야 함)
        public_holidays_in_month = []
        
        if isinstance(self.settings, dict):
            holiday_rules = self.settings.get("holiday_rules", {})
            public_holidays_in_month = holiday_rules.get("public_holidays", {}).get(period, [])
        else:
            if self.settings.holidays_config:
                start_date = datetime.date(year, month, 1)
                end_date = datetime.date(year, month, total_days_in_month)
                holidays = self.settings.holidays_config.get_holidays_for_period(start_date, end_date)
                public_holidays_in_month = [h.date.strftime("%Y-%m-%d") for h in holidays]
        
        for day_num in range(1, total_days_in_month + 1):
            try:
                current_date = datetime.date(year, month, day_num)
                date_str = current_date.strftime("%Y-%m-%d")
                # 주말 (토요일:5, 일요일:6)이 아니고, 공휴일 목록에 없으면 소정근로일
                if current_date.weekday() < 5 and date_str not in public_holidays_in_month:
                    scheduled_days += 1
            except ValueError: # 일자가 해당 월에 없는 경우 (예: 2월 30일)
                continue
        logger.info(f"Calculated scheduled_work_days for {period}: {scheduled_days}")
        return scheduled_days

    def calculate(self, attendance_data: List[AttendanceInputRecord], period_info: Dict) -> Dict:
        """
        출근 상태 데이터를 기반으로 작업 요약 및 급여 기초 정보를 계산합니다.

        Args:
            attendance_data: AttendanceInputRecord 리스트.
            period_info: 처리 대상 기간 정보 (예: {"period": "2025-05"}).

        Returns:
            딕셔너리 형태의 부분 계산 결과. WorkTimeProcessor에서 취합될 때 사용됩니다.
            주요 키: "attendance_summary", "salary_basis", "warnings", "error"
        """
        period = period_info.get("period")
        if not period:
            logger.error("Period information is missing.")
            return {"error": ErrorDetails(error_code="MISSING_PERIOD_INFO", message="기간 정보가 누락되었습니다.")}

        # 결과 초기화
        actual_work_days = Decimal("0.0")
        full_work_days = 0
        partial_work_day_ratios = []
        paid_leave_days = Decimal("0.0")
        unpaid_leave_days = Decimal("0.0")
        late_count = 0
        early_leave_count = 0
        absent_days = 0
        warnings_list: List[str] = []
        error_detail: Optional[ErrorDetails] = None

        try:
            logger.info(f"Calculating attendance for period: {period}, {len(attendance_data)} records.")
            
            total_days_in_month = self._get_days_in_month(period)
            # 소정근로일수 계산 (주말/공휴일 제외)
            # 실제로는 회사 캘린더, settings의 공휴일 정보 등을 활용해야 함
            scheduled_work_days_in_month = self._get_scheduled_work_days(period, total_days_in_month)

            for record in attendance_data:
                date_str = record.get("date")
                status_code = record.get("status_code")

                if not date_str or not status_code:
                    warnings_list.append(f"Record with missing date or status_code skipped: {record}")
                    continue

                code_definition = self.status_codes_map.get(status_code)
                if not code_definition:
                    warnings_list.append(f"Date {date_str}: Unknown status_code '{status_code}'. Will be ignored.")
                    continue # 알 수 없는 코드는 일단 무시하거나, 특정 기본값으로 처리 가능

                work_day_value = Decimal(str(code_definition.get("work_day_value", "0.0")))
                actual_work_days += work_day_value
                
                # Plan 021 부분 근무일수 계산 추가
                if work_day_value == Decimal("1.0"):
                    full_work_days += 1
                elif work_day_value > Decimal("0.0"):
                    partial_work_day_ratios.append(work_day_value)
                elif work_day_value == Decimal("0.0"):
                    absent_days += 1
                
                if code_definition.get("is_paid_leave", False):
                    paid_leave_days += work_day_value # 유급휴가도 work_day_value만큼 가산
                if code_definition.get("is_unpaid_leave", False):
                    unpaid_leave_days += Decimal(str(code_definition.get("work_day_value", "1.0"))) # 무급휴가는 보통 1일 단위로 카운트
                if code_definition.get("counts_as_late", False):
                    late_count += 1
                if code_definition.get("counts_as_early_leave", False):
                    early_leave_count += 1
            
            # AttendanceSummary 구성
            attendance_summary = AttendanceSummary(
                total_days_in_period=total_days_in_month,
                scheduled_work_days=scheduled_work_days_in_month,
                actual_work_days=actual_work_days.quantize(Decimal("0.1")), # 소수점 한자리까지
                full_work_days=full_work_days,
                partial_work_day_ratios=partial_work_day_ratios,
                absent_days=absent_days,
                paid_leave_days=paid_leave_days.quantize(Decimal("0.1")),
                unpaid_leave_days=unpaid_leave_days.quantize(Decimal("0.1")),
                late_count=late_count,
                early_leave_count=early_leave_count
            )

            # SalaryBasis 구성 (예시)
            # 실제 급여 지급 대상일수 = 소정근로일수 - (무급결근/휴가로 인한 공제일수)
            # 이 부분은 회사 정책에 따라 매우 다양할 수 있음
            deduction_days_for_salary = unpaid_leave_days # 가장 단순한 예시
            payment_target_days = Decimal(max(0, scheduled_work_days_in_month - float(deduction_days_for_salary)))
            
            salary_basis = SalaryBasis(
                # base_salary_for_period는 외부에서 주입받거나, 직원 정보와 연동 필요
                base_salary_for_period=None, # 이 계산기에서는 직접 계산하지 않음
                payment_target_days=payment_target_days.quantize(Decimal("0.1")),
                deduction_days=deduction_days_for_salary.quantize(Decimal("0.1"))
            )
            logger.info(f"Attendance calculation completed for period: {period}. Attendance Summary: {attendance_summary}")

        except Exception as e:
            log_ref_id = f"ABC_ERR_{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
            logger.error(f"Error during attendance calculation (Ref ID: {log_ref_id}): {e}", exc_info=True)
            error_detail = ErrorDetails(
                error_code="ATTENDANCE_CALCULATION_ERROR",
                message="출근 상태 기반 계산 중 오류가 발생했습니다.",
                details=str(e),
                log_ref_id=log_ref_id
            )
            # 오류 발생 시 attendance_summary, salary_basis는 None 또는 부분적일 수 있음
            return {"warnings": warnings_list, "error": error_detail}

        return {
            "attendance_summary": attendance_summary,
            "salary_basis": salary_basis,
            "warnings": warnings_list,
            "error": error_detail # 정상 완료 시 None
        }

# 사용 예시 (테스트 및 개발 중 확인용)
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # 임시 설정값 (실제로는 settings.yaml 등에서 로드)
    sample_settings = GlobalWorkSettings(
        company_settings=CompanySettings(
            daily_work_minutes_standard=480,
            weekly_work_minutes_standard=2400,
            night_shift_start_time="22:00",
            night_shift_end_time="06:00",
            attendance_status_codes={
                "1": {"work_day_value": Decimal("1.0"), "is_paid_leave": False, "is_unpaid_leave": False, "counts_as_late": False, "counts_as_early_leave": False, "description": "정상근무"},
                "0.5A": {"work_day_value": Decimal("0.5"), "is_paid_leave": True, "is_unpaid_leave": False, "counts_as_late": False, "counts_as_early_leave": False, "description": "오전 유급반차"},
                "0": {"work_day_value": Decimal("0.0"), "is_paid_leave": False, "is_unpaid_leave": True, "counts_as_late": False, "counts_as_early_leave": False, "description": "무급결근"},
                "L": {"work_day_value": Decimal("1.0"), "is_paid_leave": False, "is_unpaid_leave": False, "counts_as_late": True, "counts_as_early_leave": False, "description": "지각 (정상근무로 처리)"},
                "SICK_P": {"work_day_value": Decimal("1.0"), "is_paid_leave": True, "is_unpaid_leave": False, "counts_as_late": False, "counts_as_early_leave": False, "description": "유급병가"}
            }
        )
    )

    calculator = AttendanceBasedCalculator(settings=sample_settings)

    sample_data = [
        {"date": "2025-05-01", "status_code": "1"}, # 공휴일이지만 출근 (공휴일 근무수당은 TimeCard 모드에서)
        {"date": "2025-05-02", "status_code": "L"},
        {"date": "2025-05-03", "status_code": "1"}, # 토요일
        {"date": "2025-05-05", "status_code": "SICK_P"}, # 공휴일 + 유급병가
        {"date": "2025-05-06", "status_code": "0.5A"},
        {"date": "2025-05-07", "status_code": "0"},
        {"date": "2025-05-08", "status_code": "UNKNOWN"} # 경고 발생 예상
    ]

    result = calculator.calculate(sample_data, period_info={"period": "2025-05"})
    import json
    print(json.dumps(result, indent=2, default=str, ensure_ascii=False))

    # 소정근로일수 테스트
    # print(f"2025-02 scheduled work days: {calculator._get_scheduled_work_days('2025-02', calculator._get_days_in_month('2025-02'))}")
    # print(f"2025-05 scheduled work days (with holidays): {calculator._get_scheduled_work_days('2025-05', calculator._get_days_in_month('2025-05'))}")
