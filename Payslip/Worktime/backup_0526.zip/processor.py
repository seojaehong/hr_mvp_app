# /home/ubuntu/upload/payslip/work_time_processor.py
"""
Plan 020: 듀얼 모드 근로시간 계산기 - 통합 컨트롤러

WorkTimeProcessor는 입력 데이터와 모드에 따라 적절한 계산기를 선택하고,
계산을 실행한 후 공통 포맷으로 결과를 반환합니다.
"""

import logging
import datetime
from decimal import Decimal
from typing import Dict, List, Union, Literal, Optional

# 현재 프로젝트의 스키마를 import 합니다.
from Payslip.work_time_schema import (
    WorkTimeCalculationResult, ErrorDetails, AttendanceInputRecord, AttendanceInputData,
    TimeCardRecord, TimeCardInputData,
    GlobalWorkSettings, # WorkTimeSettings -> GlobalWorkSettings (가정)
    CompanySettings,  # CompanySettings도 명시적으로 임포트 (GlobalWorkSettings 내부 필드 타입으로 사용될 수 있음)
    AttendanceSummary, # WorkSummary -> AttendanceSummary
    SalaryBasis, TimeSummary
)
# from Payslip.attendance_calculator import AttendanceBasedCalculator # 이 임포트는 아래 클래스 정의 후로 이동하거나,
                                                                  # 순환참조 문제가 없다면 그대로 둬도 됩니다.
                                                                  # 다만, 만약을 위해 아래에서 다시 임포트하는 구조를 고려해볼 수 있습니다.

# 로거 설정
logger = logging.getLogger(__name__)

class WorkTimeProcessor:
    def __init__(self, settings: GlobalWorkSettings): # WorkTimeSettings -> GlobalWorkSettings (가정)
        """
        WorkTimeProcessor 초기화.

        Args:
            settings: 회사별 및 모듈 운영 설정을 담은 GlobalWorkSettings 객체.
        """
        self.global_settings = settings # 전체 설정을 저장
        self.company_settings = settings.company_settings # CompanySettings 추출 (GlobalWorkSettings 내부에 있다고 가정)

        # AttendanceBasedCalculator를 여기서 임포트 하거나, 클래스 외부 상단에 둬도 됩니다.
        # 만약 순환참조의 여지가 있다면, 필요한 시점에 임포트 하는 것도 방법입니다.
        from Payslip.attendance_calculator import AttendanceBasedCalculator

        self.attendance_calculator = AttendanceBasedCalculator(self.company_settings) # CompanySettings 전달 (가정)
        # self.timecard_calculator = TimeCardBasedCalculator(self.company_settings) # Plan 021 - TimeCardCalculator도 CompanySettings를 받을 것으로 예상

        # company_id 접근 방식 변경 (Pydantic 모델 가정)
        if self.company_settings and hasattr(self.company_settings, 'company_id'):
             logger.info(f"WorkTimeProcessor initialized for company_id: {self.company_settings.company_id}")
        else:
             logger.info(f"WorkTimeProcessor initialized. (Company ID not found in company_settings)")


    def _detect_mode(self, input_data: Union[List[Dict], Dict]) -> Literal["attendance", "timecard", "unknown"]:
        """
        입력 데이터의 특성을 분석하여 처리 모드를 자동으로 감지합니다.
        """
        # 이 부분은 원본 코드와 동일하게 유지
        if not input_data or not isinstance(input_data, list) or not input_data[0]:
            logger.warning("입력 데이터가 비어있거나 형식이 잘못되어 모드를 감지할 수 없습니다.")
            return "unknown"
        
        first_record = input_data[0]
        # 실제 AttendanceInputRecord 나 TimeCardRecord 의 필드를 확인하는 것이 더 정확합니다.
        # 예를 들어, status_code 는 AttendanceInputRecord 에만 있을 수 있습니다.
        if "status_code" in first_record: # AttendanceInputRecord의 주요 필드
            logger.info("Input data signature matches 'attendance' mode.")
            return "attendance"
        # TimeCardRecord의 주요 필드 (예: start_time, end_time)로 감지 로직 수정 필요
        elif "start_time" in first_record and "end_time" in first_record: # TimeCardRecord의 주요 필드
            logger.info("Input data signature matches 'timecard' mode.")
            return "timecard"
        
        logger.warning("입력 데이터에서 처리 모드를 명확히 감지할 수 없습니다.")
        return "unknown"

    def process(
        self,
        input_data: Union[List[Dict], Dict], # 실제로는 List[AttendanceInputRecord] 또는 List[TimeCardRecord] 기대
        period: str, # YYYY-MM
        employee_id: Optional[str] = None,
        mode: Literal["attendance", "timecard", "auto"] = "auto",
        # 추가: custom_fields를 받을 수 있도록 파라미터 추가 (스키마에 있었음)
        custom_fields: Optional[Dict[str, any]] = None
    ) -> WorkTimeCalculationResult:
        processed_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
        current_mode = mode
        error_detail: Optional[ErrorDetails] = None
        warnings_list: List[str] = []
        
        # 결과 초기화 (스키마에 정의된 기본값 사용)
        result = WorkTimeCalculationResult(
            employee_id=employee_id,
            period=period,
            processing_mode="unknown",
            attendance_summary=None, # work_summary -> attendance_summary
            time_summary=None,
            salary_basis=None,
            daily_calculation_details=None,
            warnings=[],
            compliance_alerts=[], # schema.py 에 있었으므로 추가
            error=None,
            processed_timestamp=processed_timestamp,
            custom_fields=custom_fields # schema.py 에 있었으므로 추가
        )

        try:
            logger.info(f"Starting work time processing for period: {period}, employee_id: {employee_id}, mode: {mode}")

            if not input_data: # 빈 리스트도 여기에 해당될 수 있으므로, Pydantic 모델로 변환 전 체크
                raise ValueError("입력 데이터가 제공되지 않았습니다.")

            if current_mode == "auto":
                current_mode = self._detect_mode(input_data) # 이미 List[Dict] 형태일 때 감지
                logger.info(f"Auto-detected mode: {current_mode}")
            
            result.processing_mode = current_mode # result가 Pydantic 모델이므로 직접 할당

            if current_mode == "attendance":
                # Pydantic 모델로 변환 및 유효성 검사
                # AttendanceInputData가 records: List[AttendanceInputRecord]를 가짐
                attendance_input = AttendanceInputData(
                    employee_id=employee_id,
                    period=period,
                    records=[AttendanceInputRecord(**record) for record in input_data], # 각 record를 Pydantic 모델로 변환
                    custom_fields=custom_fields
                )
                # attendance_calculator.calculate는 아마도 AttendanceInputData 전체를 받을 것임 (또는 records 리스트만)
                # 이 부분은 attendance_calculator.py의 calculate 메서드 시그니처 확인 필요
                partial_result = self.attendance_calculator.calculate(attendance_input.records, period_info={"period": period}) # records만 전달하는 것으로 가정
                
                # partial_result가 WorkTimeCalculationResult 와 유사한 구조의 dict를 반환한다고 가정
                if partial_result.get("attendance_summary"):
                    result.attendance_summary = AttendanceSummary(**partial_result["attendance_summary"])
                if partial_result.get("salary_basis"):
                    result.salary_basis = SalaryBasis(**partial_result["salary_basis"])
                if partial_result.get("warnings"):
                    warnings_list.extend(partial_result["warnings"])
                if partial_result.get("error"):
                    error_detail = ErrorDetails(**partial_result["error"])
                    logger.error(f"Error from AttendanceBasedCalculator: {error_detail}")

            elif current_mode == "timecard":
                # from Payslip.timecard_calculator import TimeCardBasedCalculator # 필요시 여기서 임포트
                # self.timecard_calculator = TimeCardBasedCalculator(self.company_settings) # init에서 이미 생성됨
                
                # Pydantic 모델로 변환 및 유효성 검사
                # TimeCardInputData가 records: List[TimeCardRecord]를 가짐
                # timecard_input = TimeCardInputData(
                #     employee_id=employee_id,
                #     period=period,
                #     records=[TimeCardRecord(**record) for record in input_data],
                #     custom_fields=custom_fields
                # )
                # partial_result_tc = self.timecard_calculator.calculate(timecard_input.records, period_info={"period": period})
                # if partial_result_tc.get("time_summary"):
                #     result.time_summary = TimeSummary(**partial_result_tc["time_summary"])
                # # ... (daily_details, warnings, error 등 처리)

                warnings_list.append("Timecard mode (모드 B)는 아직 구현되지 않았습니다. (Plan 021 예정)")
                logger.warning("TimeCardBasedCalculator is not yet implemented.")
                pass

            elif current_mode == "unknown":
                error_message = "입력 데이터의 처리 모드를 결정할 수 없습니다. 입력 데이터를 확인하거나 모드를 명시적으로 지정해주십시오."
                logger.error(error_message)
                error_detail = ErrorDetails(error_code="MODE_DETECTION_FAILED", message=error_message)
            else:
                error_message = f"지원하지 않는 모드입니다: {current_mode}"
                logger.error(error_message)
                error_detail = ErrorDetails(error_code="INVALID_MODE", message=error_message)

        except ValueError as ve: # Pydantic 유효성 검사 오류도 여기에 포함될 수 있음
            logger.error(f"ValueError during processing: {ve}", exc_info=True)
            error_detail = ErrorDetails(error_code="INPUT_VALIDATION_ERROR", message=str(ve), details=str(ve))
        except Exception as e:
            log_ref_id = f"WTP_ERR_{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
            logger.error(f"Unexpected error during processing (Ref ID: {log_ref_id}): {e}", exc_info=True)
            error_detail = ErrorDetails(
                error_code="UNKNOWN_PROCESSING_ERROR", 
                message="근로시간 처리 중 예상치 못한 오류가 발생했습니다.",
                details=str(e),
                log_ref_id=log_ref_id # log_ref_id 필드명 확인 (스키마에서는 log_reference_id)
            )
        finally:
            result.warnings.extend(warnings_list)
            if error_detail:
                result.error = error_detail
                result.processing_mode = "error"
            
            result.processed_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
            logger.info(f"Work time processing finished. Result error: {result.error}")

        return result

# 사용 예시 (테스트 및 개발 중 확인용)
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # 임시 설정값 (GlobalWorkSettings 구조에 맞게)
    # Payslip.work_time_schema.py에 정의된 GlobalWorkSettings, CompanySettings 등의 실제 필드 구조를 보고 맞춰야 합니다.
    # 아래는 매우 단순화된 예시입니다. 실제 필드에 맞게 채워야 Pydantic 유효성 검사를 통과합니다.
    sample_global_settings_data = {
        "company_settings": {
            "daily_work_minutes_standard": 480,
            "weekly_work_minutes_standard": 2400,
            "night_shift_start_time": "22:00",
            "night_shift_end_time": "06:00",
            "break_time_rules": [
                {"threshold_minutes": 240, "break_minutes": 30}, # 예시: 4시간 이상 근무 시 30분 휴게
                {"threshold_minutes": 480, "break_minutes": 60}  # 예시: 8시간 이상 근무 시 60분 휴게 (누적 아님, 규칙 중 가장 적합한 것)
            ],
            "attendance_status_codes": {
                "1": {"work_day_value": Decimal("1.0"), "description": "정상근무"},
                "0": {"work_day_value": Decimal("0.0"), "is_unpaid_leave": True, "description": "무급결근"},
                "SICK_P": {"work_day_value": Decimal("1.0"), "is_paid_leave": True, "description": "유급병가"},
                # company_id 와 같은 추가 필드가 CompanySettings 에 있다면 여기에 포함
            },
            "rounding_policy": {"hours_rounding": "none"},
            # "weekly_overtime_limit_buffer": 720 # 기본값이 있다면 생략 가능
        },
        # GlobalWorkSettings에 minimum_wages_config, holidays_config 등이 Optional로 있다면,
        # 해당 데이터도 여기에 포함시키거나, None으로 둘 수 있습니다.
        # "minimum_wages_config": { "root": { "2025": {"hourly_rate": 10000} } },
        # "holidays_config": { "root": [ {"date": "2025-01-01", "name": "New Year"} ] }
    }
    
    try:
        # Pydantic 모델로 변환 (실제 GlobalWorkSettings의 필드에 맞게 데이터 제공 필요)
        parsed_settings = GlobalWorkSettings(**sample_global_settings_data)
    except Exception as e:
        logger.error(f"Error parsing sample_global_settings_data into GlobalWorkSettings: {e}")
        # 이 경우 processor 생성이 불가하므로 테스트 진행 불가
        raise

    processor = WorkTimeProcessor(settings=parsed_settings)

    # 모드 A (Attendance) 테스트 데이터
    # AttendanceInputRecord는 date(datetime.date), status_code(str), worked_minutes(Optional[int])를 가짐
    sample_attendance_data_dicts: List[Dict] = [ # Pydantic 모델로 변환 전 raw dict 형태
        {"date": "2025-05-01", "status_code": "1"},
        {"date": "2025-05-02", "status_code": "SICK_P"},
        {"date": "2025-05-03", "status_code": "0"},
        {"date": "2025-05-04", "status_code": "INVALID_CODE"} # 경고 발생 예상
    ]

    logger.info("--- Testing Attendance Mode ---")
    # process 메서드는 List[Dict]를 받으므로 그대로 전달
    attendance_result = processor.process(
        input_data=sample_attendance_data_dicts, 
        period="2025-05", 
        employee_id="EMP_ATTEND", 
        mode="attendance"
    )
    import json
    # Pydantic 모델을 json으로 dump하려면 .model_dump_json() 사용 권장 (v2) 또는 .dict() 후 json.dumps (v1)
    # print(attendance_result.model_dump_json(indent=2)) # Pydantic v2
    print(json.dumps(attendance_result.model_dump() if hasattr(attendance_result, 'model_dump') else attendance_result.dict(), indent=2, default=str, ensure_ascii=False))


    logger.info("--- Testing Auto Mode (expecting attendance) ---")
    auto_attendance_result = processor.process(
        input_data=sample_attendance_data_dicts, 
        period="2025-05", 
        employee_id="EMP_AUTO_A"
    )
    print(json.dumps(auto_attendance_result.model_dump() if hasattr(auto_attendance_result, 'model_dump') else auto_attendance_result.dict(), indent=2, default=str, ensure_ascii=False))

    # 모드 B (Timecard) 테스트 데이터 (간단히 형식만 맞춤)
    # TimeCardRecord는 date(datetime.date), start_time(str), end_time(str), break_time_minutes(Optional[int]) 등을 가짐
    sample_timecard_data_dicts: List[Dict] = [
        {"date": "2025-05-01", "start_time": "09:00", "end_time": "18:00", "break_time_minutes": 60}
    ]

    logger.info("--- Testing Timecard Mode (expecting not implemented warning) ---")
    timecard_result = processor.process(
        input_data=sample_timecard_data_dicts, 
        period="2025-05", 
        employee_id="EMP_TIME", 
        mode="timecard"
    )
    print(json.dumps(timecard_result.model_dump() if hasattr(timecard_result, 'model_dump') else timecard_result.dict(), indent=2, default=str, ensure_ascii=False))
    
    # (이하 테스트 케이스 생략 - 유사하게 수정)